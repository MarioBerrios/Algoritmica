#ifndef FUNTIONALITY_HPP
#define FUNTIONALITY_HPP

    void ordenacionQuickSort();
    void determinanteIterativo();
    void determinanteRecursivo();

#endif