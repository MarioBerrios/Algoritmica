#ifndef FUNCIONESMEDIONIVEL_H
#define FUNCIONESMEDIONIVEL_H

    void metodoEMax();
    void metodoISE();

#endif