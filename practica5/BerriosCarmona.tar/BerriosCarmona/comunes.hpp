#ifndef COMUNES_H
#define COMUNES_H
    
    #include <vector>

    bool lugar(const std::vector<int> &tablero, const int fila);

#endif