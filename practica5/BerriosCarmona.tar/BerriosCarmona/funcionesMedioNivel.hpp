#ifndef FUNCIONESMEDIONIVEL_H
#define FUNCIONESMEDIONIVEL_H

    void nReinasTodasBT();
    void nReinasUnaBT();
    void nReinasVegas();
    void nReinasPodaBT();
    void verificarProductoMatrices();
    void verificarFallar();

#endif