#ifndef FUNCIONESMEDIONIVEL_H
#define FUNCIONESMEDIONIVEL_H

    void metodo1();
    void metodo2();

#endif