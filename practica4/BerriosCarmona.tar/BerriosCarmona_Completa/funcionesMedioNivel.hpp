#ifndef FUNCIONESMEDIONIVEL_H
#define FUNCIONESMEDIONIVEL_H

    void metodoDinamica();
    void metodoAestrella();

#endif